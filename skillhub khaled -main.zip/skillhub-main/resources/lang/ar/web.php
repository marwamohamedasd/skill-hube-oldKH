<?php

return[

    'home'=>'الرئيسية',
    'cats'=>'التصنيفات',
    'Contact'=>'اتصل بينا ',
    'SignIn'=>'نسجيل الدخول ',
    'SignUp'=>'تسجيل الخروج',
    'Programming'=>'البرمجة',
     'Design'=>'التصميم',
     'Management'=>'الادارة',
     'test-skill'=>'موقع اختبارات المهارات',
     'sign-test-youskills'=>'سجل معنا واختبر مهاراتك اون لاين',
     'start'=>'ابدء الان',
     'Popular_Exams'=>'امتحانات مشهورة',




     'getInTouch'=>'كن على تواصل معنا ',
     'sendMsg'=>'ارسل رسالة',
     'send'=>'ارسال',
     'signup'=>'التسجيل',
     'name'=>'الاسم ',
     'email'=>'البريد الاليكترونى',
     'subject'=>'الموضوع',
      'msg'=>'الرسالة ',
      'signout'=>'نسجيل الخروج',
      'contactInfo'=>'بيانات التواصل',
      'signin'=>'تسجيل الدخول',
      'password'=>'كلمة السر',
      'confirmPassword'=>'تاكيد كلمة السر ',
      'forgot-password'=>'نسيت كلمة السر',
      'submit'=>'ارسال',
      'start-exam'=>'بدء الامتحان',
      'profile'=>'الصفحة الشخصية',
      'dashboard'=>'لوحة التحكم '

];



?>
