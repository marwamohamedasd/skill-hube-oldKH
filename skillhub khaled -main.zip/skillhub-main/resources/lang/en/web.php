<?php

return[

    'home'=>'Home',
    'cats'=>'categories',
    'Contact'=>'Contact US',
    'Programming'=>'Programming',
     'Design'=>'Design',
     'Management'=>'Management',
     'SignIn'=>'Sign In',
     'SignUp'=>'Sign Up',
     'test-skill'=>'SkillsHub Free Online Skill Assessment',
     'sign-test-youskills'=>'sign with us and test your skills online',
     'start'=>'Get Started!',
     'Popular_Exams'=>'Popular Exams',



     'getInTouch'=>'Get In Touch',
     'sendMsg'=>'send Message',
     'send'=>'Send',
     'signout'=>'Sign Out',
     'name'=>'Name',
     'email'=>'Email',
     'contact'=>'Contast Us',
     'msg'=>'Message',
      'contactInfo'=>'Contact Information',
      'signin'=>'Sign In',
      'password'=>'password',
      'submit'=>'Submit',
      'forgot-password'=>'Forgot Password',
      'start-exam'=>'start Exam',
      'profile'=>'Profile' ,
      'dashboard'=>'Dash Board'


];

?>
